numero = int(input("digite numero:\n"))
inicio = 1
soma = 0
while inicio <= numero:
    soma = soma + inicio
    print(soma)
    inicio = inicio + 1
print(soma)