#!/usr/bin/env python
# _*_ coding: utf-8

print (20 + 5) * (4 + 2)
