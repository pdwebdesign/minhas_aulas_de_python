#!/usr/bin/env python
# _*_ coding: utf-8

euro = 1.35
print 65.54 * euro
