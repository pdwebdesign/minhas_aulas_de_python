while True:
    numero = int(input("digite um numero"))
    if numero > 0 and numero < 10:
        print("NUmero valido")
        break

