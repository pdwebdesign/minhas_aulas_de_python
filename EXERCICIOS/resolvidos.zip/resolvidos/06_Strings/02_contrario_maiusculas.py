nome = raw_input('Informe seu nome: ')
print nome.upper()[::-1]
