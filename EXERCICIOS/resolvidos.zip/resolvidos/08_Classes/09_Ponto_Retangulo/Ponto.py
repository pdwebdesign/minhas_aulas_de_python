class Ponto:
    def __init__(self, x, y):
        self.x = x
        self.y = y

    def imprimeValores(self):
        print('X: %d, Y: %d' % (self.x, self.y))
