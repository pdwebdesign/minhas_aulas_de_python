numbers = []
for i in range(0, 10):
    numbers.append(int(input('Informe um numero: ')))

numbers.reverse()
print(numbers)
