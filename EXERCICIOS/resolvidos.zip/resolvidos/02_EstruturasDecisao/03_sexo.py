sexo = raw_input('Informe F para FEMININO ou M para MASCULINO: ')

if (sexo.upper() == 'M'):
    print 'MASCULINO'
elif (sexo.upper() == 'F'):
    print 'FEMININO'
else:
    print 'Sexo Invalido'
