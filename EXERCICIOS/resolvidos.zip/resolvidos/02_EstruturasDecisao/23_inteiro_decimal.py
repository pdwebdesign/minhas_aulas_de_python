valor = float(raw_input('Informe um numero: '))

if (valor == int(valor)):
    print 'Valor eh inteiro'
else:
    print 'Valor eh decimal'
