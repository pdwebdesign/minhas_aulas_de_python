valor = int(raw_input('Informe um numero: '))

if (valor % 2 == 0):
    print 'Valor eh par'
else:
    print 'Valor eh impar'
