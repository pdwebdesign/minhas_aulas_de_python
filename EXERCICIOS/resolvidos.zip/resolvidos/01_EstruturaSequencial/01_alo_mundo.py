print 'Alo mundo'
