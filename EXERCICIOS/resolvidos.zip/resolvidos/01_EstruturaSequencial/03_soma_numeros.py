num1 = int(raw_input("Informe um numero: "))
num2 = int(raw_input("Informe outro numero: "))
print "A soma de", num1, "e", num2, "=", (num1 + num2)
