valorPorHora = int(raw_input('Qual o valor da sua hora trabalhada: '))
horas = int(raw_input('Informe a quantidade de horas trabalhadas: '))
print 'Seu salario neste mes sera', valorPorHora * horas
