import math

raio = int(raw_input("Informe a medida do raio de um circulo: "))
print "A area do circulo de raio", raio, "eh", (2*math.pi*raio)
