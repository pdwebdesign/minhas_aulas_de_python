def retornaInvertido(valor):
    return valor[::-1]

numero = raw_input('Informe um numero: ')
print retornaInvertido(numero)
