soma = 0
for i in range(0, 5):
    numero = int(input('Informe um numero: '))
    soma += numero

print('A soma dos numeros digitados eh', soma)
print('A media dos numeros digitados eh', (soma / 5.0))
