numbers = []
for i in range(0, 10):
    numbers.append(int(raw_input('Informe um numero: ')))

numbers.reverse()
print numbers
