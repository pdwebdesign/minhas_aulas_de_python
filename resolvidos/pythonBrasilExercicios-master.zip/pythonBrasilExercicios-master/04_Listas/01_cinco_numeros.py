numbers = []
for i in range(0, 5):
    numbers.append(int(raw_input('Informe um numero: ')))

print numbers
