def soma(valor1, valor2, valor3):
    return valor1 + valor2 + valor3

valor1 = int(raw_input('Informe o primeiro valor: '))
valor2 = int(raw_input('Informe o segundo valor: '))
valor3 = int(raw_input('Informe o terceiro valor: '))

print 'A soma dos valores e %d' % soma(valor1, valor2, valor3)
