Exercícios resolvidos de Python. Lista disponível no site do Python Brasil:

http://www.python.org.br/wiki/ListaDeExercicios

Tutorial Python:

http://www.tutorialspoint.com/python/index.htm