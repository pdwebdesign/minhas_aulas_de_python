altura = float(raw_input('Informe a sua altura: '))
pesoIdeal = (72.7 * altura) - 58
print 'Seu peso ideal eh', pesoIdeal
