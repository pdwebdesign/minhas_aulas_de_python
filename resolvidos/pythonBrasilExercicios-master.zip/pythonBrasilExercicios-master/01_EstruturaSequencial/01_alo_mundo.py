print 'Alo mundo'
