lado = int(raw_input("Informe a medida do lado de um quadrado: "))
print "A area do quadrado de lado", lado, "eh", (lado * lado)
print "O dobro da area eh", 2*(lado * lado)
