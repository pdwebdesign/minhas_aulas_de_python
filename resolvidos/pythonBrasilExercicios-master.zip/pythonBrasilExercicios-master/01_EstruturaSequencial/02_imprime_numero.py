x = int(raw_input("Informe um numero: "))
print "O numero informado foi:", x
