farenheit = int(raw_input('Informe a temperatura em Farenheit: '))
celsius = 5 * (farenheit - 32) / 9.0
print "A temperatura em Celsius eh", celsius
