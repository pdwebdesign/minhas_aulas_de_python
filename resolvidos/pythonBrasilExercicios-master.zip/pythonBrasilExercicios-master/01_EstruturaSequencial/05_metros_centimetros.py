metros = int(raw_input('Informe o valor em metros: '))
print 'O valor em centimetros eh', metros * 100
