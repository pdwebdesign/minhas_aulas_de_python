nome = raw_input('Informe seu nome: ')
for i in range(0, len(nome)):
    print nome[i]
