# Imprime os numeros um abaixo do outro
for i in range(1, 21):
    print i

# Imprime os numeros um ao lado do outro
for i in range(1, 21):
    print i,
