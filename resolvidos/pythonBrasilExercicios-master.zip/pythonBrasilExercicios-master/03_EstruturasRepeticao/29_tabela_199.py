print 'Loja Quase Dois - Tabela de precos'
for i in range(1, 51):
    print '%d - R$ %.2f' % (i, i * 1.99)
