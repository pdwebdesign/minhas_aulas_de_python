primeiro = 0
print primeiro
segundo = 1
while (segundo < 500):
    print segundo
    terceiro = primeiro + segundo
    primeiro = segundo
    segundo = terceiro
