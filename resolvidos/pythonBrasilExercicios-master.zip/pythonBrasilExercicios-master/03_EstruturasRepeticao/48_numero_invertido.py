numero = raw_input('Informe um numero: ')

print numero[::-1]
