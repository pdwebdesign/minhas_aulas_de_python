class Retangulo:

    def __init__(self, altura, largura, centro):
        self.altura = altura
        self.largura = largura
        self.centro = centro

    def mostraCentro(self):
        self.centro.imprimeValores()
